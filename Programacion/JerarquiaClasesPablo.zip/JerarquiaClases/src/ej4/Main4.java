package ej4;

public class Main4 {



	public static void main(String[] args) {



		empleado E1 = new empleado("Rafa");

		directivo D1 = new directivo("Mario");

		operario OP1 = new operario("Alfonso");

		oficial OF1 = new oficial("Luis");

		tecnico T1 = new tecnico("Pablo");



		System.out.println(E1);

		System.out.println(D1);

		System.out.println(OP1);

		System.out.println(OF1);

		System.out.println(T1);

	}



}
