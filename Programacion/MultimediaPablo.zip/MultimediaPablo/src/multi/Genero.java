package multi;

public enum Genero {
	rock, pop, funk;
}
