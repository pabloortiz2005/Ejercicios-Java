package multi;

public enum Formato {
	cdAudio,dvd,wav,mp3,midi,mov,mpg,avi;
}
