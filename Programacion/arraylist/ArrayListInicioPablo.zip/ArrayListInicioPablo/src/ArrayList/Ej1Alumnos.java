package ArrayList;

import java.util.ArrayList;

public class Ej1Alumnos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		ArrayList<String> Alumnos = new ArrayList<String>();

		Alumnos.add("Rodrigo Moreno Aguilar");
		Alumnos.add("Jose Ignacio Echevarria Castill");
		Alumnos.add("Martin Izquierdo Cuevas");
		Alumnos.add("Patricia Aguayo Escudero");
		Alumnos.add("Iván García Espaliú");
		Alumnos.add("Carla Dominguez Espinosa");
		Alumnos.add("Rafael Auxilia Esquina");
		Alumnos.add("Alberto Bernet Fernández");
		Alumnos.add("Francisco Javier Gutiérrez Fuentes");
		Alumnos.add("Antonio Guerrero García");
		Alumnos.add("Nicolás Ganfornina García");
		Alumnos.add("Andrea Rodriguez Gonzalez");
		Alumnos.add("Maria Minque López Guillén");
		Alumnos.add("Victor Bejar Martin");
		Alumnos.add("José Manuel Flores Marzo");
		Alumnos.add("Andrea Catalán Menacho");
		Alumnos.add("Raul Martin Torrabadella Mendoza");
		Alumnos.add("Pablo Ortiz Muñoz");
		Alumnos.add("Miguel Muñoz Rivas");
		Alumnos.add("Daniel Navarro Vázquez");
		
		for (String a:Alumnos) {
			System.out.print(a + ", ");
		}
		
	}
}
